Pattern Recognition Project 01
------------------------------
by Lukas Drexler, Leif Van Holland, Reza Jahangiri, Mark Springer and Maximilian Thiessen

Solutions of the individual tasks can be found in the corresponding .py files,
plots are in the folder 'plots'.

The presentation is enclosed in presentation.pdf.